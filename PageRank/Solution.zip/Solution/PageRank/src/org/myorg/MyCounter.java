package org.myorg;

public enum MyCounter {
	RESIDUAL_COUNTER;
}
